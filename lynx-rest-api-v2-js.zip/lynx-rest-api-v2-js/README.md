# Lynx Apis V2 (JavaScript)

Web REST API starter in JavaScript, different from V1:
- landing page
- docs page
- endpoint browser
- endpoint playground
- plugin-based API routes
- file upload + image/binary response support

## Run
```bash
npm install
cp .env.example .env
npm run dev
```

Open:
- `/` for home
- `/docs` for documentation
- `/playground` for endpoint tester
- `/api/health` for health check

## Structure
- `server.js` main app
- `lib/plugins/*` endpoint plugins
- `lib/registry.js` plugin registry
- `public/` frontend assets
