import express from 'express'
import cors from 'cors'
import morgan from 'morgan'
import multer from 'multer'
import dotenv from 'dotenv'
import path from 'path'
import { fileURLToPath } from 'url'
import { plugins, categories, findPlugin } from './lib/registry.js'

dotenv.config()

const app = express()
const __filename = fileURLToPath(import.meta.url)
const __dirname = path.dirname(__filename)
const BRAND = process.env.BRAND || 'Lynx Apis V2'
const PORT = Number(process.env.PORT || 3000)

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 15 * 1024 * 1024 }
})

app.use(cors())
app.use(morgan('dev'))
app.use(express.json({ limit: '10mb' }))
app.use(express.urlencoded({ extended: true }))
app.use(express.static(path.join(__dirname, 'public')))

function basePayload(extra = {}) {
  return {
    status: true,
    code: 200,
    creator: BRAND,
    timestamp: new Date().toISOString(),
    ...extra
  }
}

function bad(res, code, message, extra = {}) {
  return res.status(code).json({
    status: false,
    code,
    creator: BRAND,
    message,
    ...extra
  })
}

function normalizeForm(req) {
  const input = { ...req.body }
  if (req.file) {
    input.file = {
      name: req.file.originalname,
      type: req.file.mimetype,
      size: req.file.size,
      bytes: new Uint8Array(req.file.buffer),
      base64: `data:${req.file.mimetype};base64,${req.file.buffer.toString('base64')}`
    }
  }
  return input
}

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'))
})

app.get('/docs', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'docs.html'))
})

app.get('/playground', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'playground.html'))
})

app.get('/api/health', (req, res) => {
  res.json(basePayload({
    message: 'API is alive',
    version: '2.0.0',
    endpoints: plugins.length
  }))
})

app.get('/api/meta', (req, res) => {
  res.json(basePayload({
    brand: BRAND,
    categories,
    endpoints: plugins.map(p => ({
      title: p.title,
      slug: p.slug,
      category: p.category,
      method: p.method,
      path: p.path,
      description: p.description
    }))
  }))
})

app.all('/api/:category/:endpoint', upload.single('file'), async (req, res) => {
  try {
    const { category, endpoint } = req.params
    const plugin = findPlugin(category, endpoint)

    if (!plugin) return bad(res, 404, 'Endpoint not found')
    if (req.method !== plugin.method) {
      return bad(res, 405, `Method ${req.method} not allowed. Use ${plugin.method}.`)
    }

    let input = {}

    if (plugin.method === 'GET') {
      input = { ...req.query }
    } else if (plugin.bodyType === 'json') {
      input = req.body || {}
    } else if (plugin.bodyType === 'form-data') {
      input = normalizeForm(req)
    } else {
      input = { ...req.query }
    }

    for (const p of plugin.parameters || []) {
      if (p.required && (input[p.name] === undefined || input[p.name] === null || input[p.name] === '')) {
        return bad(res, 400, `Parameter ${p.name} is required`)
      }
    }

    const result = await plugin.run(input)

    if (result?.rawBuffer && result?.mimeType) {
      const buffer = Buffer.isBuffer(result.rawBuffer)
        ? result.rawBuffer
        : Buffer.from(result.rawBuffer)
      return res.status(200).set('Content-Type', result.mimeType).send(buffer)
    }

    const status = result?.code && result.code >= 400 ? result.code : 200
    return res.status(status).json(result)
  } catch (error) {
    return bad(res, 500, error?.message || 'Internal Server Error')
  }
})

app.use((req, res) => {
  bad(res, 404, 'Route not found')
})

app.listen(PORT, () => {
  console.log(`[${BRAND}] running on http://localhost:${PORT}`)
})
