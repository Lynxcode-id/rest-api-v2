const $ = (q, el = document) => el.querySelector(q)
const $$ = (q, el = document) => [...el.querySelectorAll(q)]

async function loadMeta() {
  const r = await fetch('/api/meta')
  return r.json()
}

function endpointCard(ep) {
  return `
    <div class="card">
      <div class="pill">${ep.method}</div>
      <h3 style="margin-top:12px">${ep.title}</h3>
      <p style="margin:10px 0 14px">${ep.description || ''}</p>
      <div class="muted" style="font-size:13px">${ep.path}</div>
    </div>
  `
}

async function bootHome() {
  const meta = await loadMeta()
  const root = $('#stats')
  if (!root) return
  root.innerHTML = `
    <div class="card kpi"><span class="muted">Categories</span><strong>${meta.categories.length}</strong></div>
    <div class="card kpi"><span class="muted">Endpoints</span><strong>${meta.endpoints.length}</strong></div>
    <div class="card kpi"><span class="muted">Version</span><strong>V2</strong></div>
  `
  const list = $('#featured')
  if (list) list.innerHTML = meta.endpoints.slice(0, 4).map(endpointCard).join('')
}

async function bootDocs() {
  const meta = await loadMeta()
  const root = $('#docs-root')
  if (!root) return
  root.innerHTML = `
    <div class="panel">
      <h2>Categories</h2>
      <div class="cards" style="grid-template-columns:repeat(3,1fr)">
        ${meta.categories.map(c => `<div class="card"><div class="pill">${c.slug}</div><h3 style="margin-top:10px">${c.title}</h3><p>${c.count} endpoints</p></div>`).join('')}
      </div>
    </div>
    <div class="section panel">
      <h2>All Endpoints</h2>
      <table class="table">
        <thead><tr><th>Name</th><th>Route</th><th>Method</th><th>Category</th></tr></thead>
        <tbody>
          ${meta.endpoints.map(ep => `<tr><td>${ep.title}</td><td>${ep.path}</td><td>${ep.method}</td><td>${ep.category}</td></tr>`).join('')}
        </tbody>
      </table>
    </div>
  `
}

function renderFields(params) {
  return params.map(p => {
    const type = p.type === 'textarea' ? 'textarea' : (p.type === 'file' ? 'file' : 'text')
    if (type === 'textarea') {
      return `
        <div class="grid">
          <label>
            <div class="muted" style="margin-bottom:8px">${p.name}${p.required ? ' *' : ''}</div>
            <textarea class="textarea" name="${p.name}" placeholder="${p.example || p.description || ''}"></textarea>
          </label>
        </div>
      `
    }
    if (type === 'file') {
      return `
        <label>
          <div class="muted" style="margin-bottom:8px">${p.name}${p.required ? ' *' : ''}</div>
          <input class="input" type="file" name="${p.name}" accept="${p.accept || '*/*'}">
        </label>
      `
    }
    return `
      <label>
        <div class="muted" style="margin-bottom:8px">${p.name}${p.required ? ' *' : ''}</div>
        <input class="input" type="${p.type === 'number' ? 'number' : 'text'}" name="${p.name}" placeholder="${p.example || p.description || ''}">
      </label>
    `
  }).join('')
}

async function bootPlayground() {
  const meta = await loadMeta()
  const select = $('#endpointSelect')
  const form = $('#playForm')
  const output = $('#responseBox')
  const img = $('#responseImage')
  if (!select || !form) return

  const makeOptions = () => meta.endpoints.map((ep, i) => `<option value="${i}">${ep.category}/${ep.slug} — ${ep.method}</option>`).join('')
  select.innerHTML = makeOptions()

  function syncForm() {
    const ep = meta.endpoints[Number(select.value)]
    $('#selectedRoute').textContent = ep.path
    $('#selectedDesc').textContent = ep.description || ''
    $('#formFields').innerHTML = renderFields(ep.parameters || [])
  }

  select.addEventListener('change', syncForm)
  syncForm()

  form.addEventListener('submit', async (e) => {
    e.preventDefault()
    const ep = meta.endpoints[Number(select.value)]
    const fd = new FormData(form)
    let res

    if (ep.method === 'GET') {
      const qs = new URLSearchParams()
      for (const [k, v] of fd.entries()) if (v instanceof File ? v.size : String(v).length) qs.append(k, v)
      res = await fetch(ep.path + '?' + qs.toString())
    } else if (ep.bodyType === 'json') {
      const obj = Object.fromEntries([...fd.entries()].map(([k, v]) => [k, v]))
      res = await fetch(ep.path, { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(obj) })
    } else {
      res = await fetch(ep.path, { method: 'POST', body: fd })
    }

    const ct = res.headers.get('content-type') || ''
    img.style.display = 'none'
    output.style.display = 'block'

    if (ct.startsWith('image/')) {
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      img.src = url
      img.style.display = 'block'
      output.textContent = JSON.stringify({ status: true, code: res.status, message: 'Binary image response' }, null, 2)
      return
    }

    const text = await res.text()
    try {
      output.textContent = JSON.stringify(JSON.parse(text), null, 2)
    } catch {
      output.textContent = text
    }
  })
}

bootHome()
bootDocs()
bootPlayground()
